# CS106L-spr20

Welcome to the CS 106L Github Page!
We will post all lecture code and exercises here. 
Assignments are delivered using a Qt Creator file, which 
is available on the class website.

Currently available:

L1-intro

L2-structures

L3-references

L4-streams

L5-containers

L6-iterators

L7-templates

L8-functions

L9-summary

L10-template-classes

L11-const

L12-operators

L13-special-member-functions

L14-move-semantics

L15-raii

L16-multithreading

L17-final/functors
