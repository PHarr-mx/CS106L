#ifndef STREAMINGMEDIAN_H
#define STREAMINGMEDIAN_H

#include <algorithm>
#include <functional>
// feel free to include anything else

namespace mycollection {
    template <typename T, typename Compare = std::less<T>>
    class StreamingMedianTracker {
    public:

        using const_reference = const T&;
        // Your task: design a data structure StreamingMedianTracker that stores of type T
        // and a comparison function of type Compare
        // and allows the following operations:
        // (1) insert one element of type T
        // (2) insert a range of elements of type T
        // (3) query the median of all elements inserted so far
        // median is defined as the element in the middle when all elements are sorted by comparison function
        // if there are two middle elements (i.e. even number of elements), return the smaller middle element.

        // example:
        // insert 3, insert 9, insert 6, query -> should return 6
        // insert 3, insert 9, query -> should return 3 (middle elements are 3 and 9)


        StreamingMedianTracker(const Compare& comp = Compare());
        ~StreamingMedianTracker();                   // only if necessary - we recommend you don't use your own dynamic arrays
        void insert(const_reference elem);
        const_reference getMedian() const;


        // this is just extra practice for template methods inside of a template class
        // don't overthink the implementation - just go through the entire range and call the single-element insert.
        template <typename InputIt>
        void insert(InputIt first, InputIt last);    // inserts all elements in range [first, last)

    private:
        /* TODO: add any private members (variables) here */
    };

    template <typename T, typename Compare>
    StreamingMedianTracker<T, Compare>::StreamingMedianTracker(const Compare& comp) {
        // TODO: complete the implementation of this function
    }

    // TODO: declare the other methods above!
}



#endif // STREAMINGMEDIAN_H
